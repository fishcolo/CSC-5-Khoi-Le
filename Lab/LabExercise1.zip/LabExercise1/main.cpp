/* 
 * File:   main.cpp
 * Author: Khoi Le
 * Created on June 28, 2022, 4:18 PM
 * Purpose: Minimizing fuel cost
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float gasGage, tankSize, gasMileage, priceGas1, priceGas2, milesToGas1, milesToGas2;

    
    //Initialized Variables
    gasGage = 0.75;
    tankSize = 22;
    gasMileage = 17;
    priceGas1 = 4.25;
    priceGas2 = 4.09;
    milesToGas1 = 10;
    milesToGas2 = 20;
    //Map inputs to outputs -> The Process
    float gasRequired = tankSize * (1 - gasGage);
    float costToFill1 = gasRequired * priceGas1;
    float costToFill2 = gasRequired * priceGas2; 
    float costToDrive1 = (milesToGas1 / gasMileage) * priceGas1 * 2;
    float costToDrive2 = (milesToGas2 / gasMileage) * priceGas2 * 2;
    float fillAndDrive1 = costToDrive1 + costToFill1;
    float fillAndDrive2 = costToDrive2 + costToFill2;
    float finalPricePerGallon1 = fillAndDrive1 / gasRequired;
    float finalPricePerGallon2 = fillAndDrive2 / gasRequired;
    //Display Results
    cout <<"At gas station 1:"<< endl;
    cout <<"Cost to fill up is: "<< costToFill1 << endl;
    cout <<"Distance back and forth to gas station: "<< milesToGas1 << endl;
    cout <<"Cost to drive back and forth to gas station: "<< costToDrive1 << endl;
    cout <<"Cost to fill and drive: "<< fillAndDrive1 << endl;
    cout <<"Final price per gallon when adding in mileage to station: "<< finalPricePerGallon1 << endl;
            
    cout <<"At gas station 2:"<< endl;
    cout <<"Cost to fill up is: "<< costToFill2 << endl;
    cout <<"Distance back and forth to gas station: "<< milesToGas2 << endl;
    cout <<"Cost to drive back and forth to gas station: "<< costToDrive2 << endl;
    cout <<"Cost to fill and drive: "<< fillAndDrive2 << endl;
    cout <<"Final price per gallon when adding in mileage to station: "<< finalPricePerGallon2;
    //Exit Stage Right
    return 0;
}

