
/* 
 * File:   main.cpp
 * Author: Khoi Le
 * Created on July 10th, 2022, at 11:37 
 * Purpose:  Basic Menu for Homework and Exams
 */

//System Libraries
#include <iostream>   //Input/Output Library
using namespace std;  //STD Name-space where Library is compiled

//User Libraries

//Global Constants not Variables
//Math/Physics/Science/Conversions/Dimensions

//Function Prototypes

//Code Begins Execution Here with function main
int main(int argc, char** argv) {
    //Set random number seed once here
    
    //Declare variables here
    int choose;//Choose a problem
    
    //Initialize variables here
    do{
        //List of Problems which can be run by the program
        cout<<"Choose from the following Menu Items"<<endl;
        cout<<"Problem 0"<<endl;
        cout<<"Problem 1"<<endl;
        cout<<"Problem 2"<<endl;
        cout<<"Etc......"<<endl;
        cout<<"9 or greater, all negatives to exit"<<endl;
        cin>>choose;
        
        switch(choose){
            case 0:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string name1, name2, name3;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Sorting Names" << endl;
    cout << "Input 3 names" << endl;
    cin >> name1 >> name2 >> name3; 
    if(name1 > name2 && name1 > name3)
    {
        if(name2 > name3)
        {
            cout << name3 << "\n" << name2 << "\n" << name1;
        }
        else
        {
            cout << name2 << "\n" << name3 << "\n" << name1;
        }
    }
    else if(name2 > name1 && name2 > name3)
    {
        if(name1 > name3)
        {
            cout << name3 << "\n" << name1 << "\n" << name2;
        }
        else
        {
            cout << name1 << "\n" << name3 << "\n" << name2;
        }
    }
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 1:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int books, points;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Book Worm Points" << endl;
    cout << "Input the number of books purchased this month." << endl;
    cin >> books;
    
    if(books == 0)
    {
        points = 0;
    }
    
    else if(books == 1)
    {
        points = 5;
    }
    
    else if(books == 2)
    {
        points = 15;
    }
    
    else if(books == 3)
    {
        points = 30;
    }
    
    else if(books >= 4)
    {
        points = 60;
    }
    cout << "Books purchased =  " << books << endl;
    cout << "Points earned   = " << points;
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 2:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float balance, checks, checkFee, monthlyFee, lowBalance, newBalance;
    //Initialize or input i.e. set variable values
   monthlyFee = 10;
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Monthly Bank Fees" << endl;
    cout << "Input Current Bank Balance and Number of Checks" << endl;
    cin >> balance >> checks;
    
        if(balance < 400)
    {
        lowBalance = 15;
    }
    
    else
    {
        lowBalance = 0;
    }
    if(checks == 0)
    {
        checkFee = checks * 0;
    }
    
    else if(checks > 0 && checks < 20)
    {
        checkFee = checks * 0.1;
    }
    
    else if(checks >= 20 && checks <= 39)
    {
        checkFee = checks * 0.08;
    }
    
    else if(checks >= 40 && checks <= 59)
    {
        checkFee = checks * 0.06;
    }
    
    else if(checks >= 60)
    {
        checkFee = checks * 0.04;
    }
    
    else if(checks < 0)
    {
        cout << "Account is overdrawn!" << endl;;
        return 0;
    }
    
    newBalance = balance - checkFee - monthlyFee - lowBalance;
    cout << "Balance     $" << fixed << setprecision(2) << setw(9) << balance << endl;
    cout << "Check Fee   $" << setw(9) << checkFee << endl;
    cout << "Monthly Fee $" << setw(9) << monthlyFee << endl;
    cout << "Low Balance $" << setw(9) << lowBalance << endl;
    cout << "New Balance $" << setw(9) << newBalance;
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 3:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string name1, name2, name3;
    int time1, time2, time3;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Race Ranking Program" << endl;
    cout << "Input 3 Runners\nTheir names, then their times" << endl;
    cin >> name1 >> time1 >> name2 >> time2 >> name3 >> time3;
    
    if(time1 > time2 && time1 > time3)
    {
        if(time2 > time3)
        {
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name1 << "\t" << setw(3) << time1;
        }
        else
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name1 << "\t" << setw(3) << time1;
    }
    
    else if(time3 > time1 && time3 > time2)
    {
        if(time1 < time2)
        {
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name3 << "\t" << setw(3) << time3;    
        }
        else
        {
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name3 << "\t" << setw(3) << time3;   
        }
    }
    
    else if(time2 > time1 && time2 > time3)
    {
        if(time1 < time3)
        {
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name2 << "\t" << setw(3) << time2;
        }
        else
        {
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name2 << "\t" << setw(3) << time2;
        }
    }
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 4:cout<<"cout << "ISP Bill" << endl;
    cout << "Input Package and Hours" << endl;
    cin >> package >> hours;
    
    if(package == 'A')
    {
       if(hours <= 10)
       {
           cost = 9.95;
       }
       else
       {
           cost = 9.95 + (hours - 10) * 2;
       }
    }
    else if(package == 'B')
    {
       if(hours <= 20)
       {
           cost = 14.95;
       }
       else
       {
           cost = 14.95 + (hours - 20);
       }
    }
    else
    {
    if(package == 'C')
        {
            cost = 19.95;
        }
    }
    
    cout << "Bill = $" << fixed << setprecision(2) << setw(6) << cost;
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 5:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    char play1, play2;

    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Rock Paper Scissors Game" << endl;
    cout << "Input Player 1 and Player 2 Choices" << endl;
    cin >> play1 >> play2;
    
    if(play1 == 'R' || play1 == 'r')
    {
        if(play2 == 'P' || play2 == 'p')
        {
            cout << "Paper covers rock.";
        }
        else if(play2== 'S' || play2 == 's')
        {
            cout << "Rock breaks scissors.";
        }    
        else
        {
            cout << "Nobody wins";
        }
    }
        if(play1 == 'S' || play1 == 's')
    {
        if(play2 == 'P' || play2 == 'p')
        {
            cout << "Scissors cut paper.";
        }
        else if(play2== 'R' || play2 == 'r')
        {
            cout << "Rock breaks scissors.";
        }    
        else
        {
            cout << "Nobody wins";
        }
    }
        if(play1 == 'P' || play1 == 'p')
    {
        if(play2 == 'R' || play2 == 'r')
        {
            cout << "Paper covers rock.";
        }
        else if(play2== 'S' || play2 == 's')
        {
            cout << "Scissors cuts paper.";
        }    
        else if(play1 == play2)
        {
            cout << "Nobody wins.";
        }
    }
    
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 6:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Arabic to Roman numeral conversion." << endl;
    cout << "Input the integer to convert." << endl;
    cin >> number;
    
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 7:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string sign1, sign2, sign;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Horoscope Program which examines compatible signs." << endl;
    cout << "Input 2 signs." << endl;
    cin >> sign1 >> sign2;
    
    if(sign1 == 'Aeries' || sign1 == 'Leo' || sign1 == 'Sagittarius')
    {
        sign1 = 'fire';
    }
    else if(sign1 == 'Taurus' || sign1 == 'Virgo' || sign1 == 'Capricorn')
    {
        sign1 = 'earth';
    }
    else if(sign1 == 'Gemini' || sign1 == 'Libra' || sign1 == 'Aquarius')
    {
        sign1 = 'air';
    }
    else if(sign1 == 'Cancer] || sign1 == 'Scorpio' || sign1 == 'Pisces')
    {
        sign1 = 'water';
    }
    
    if(sign2 == 'Aeries' || sign2 == 'Leo' || sign2 == 'Sagittarius')
    {
        sign2 = 'fire';
    }
    else if(sign2 == 'Taurus' || sign2 == 'Virgo' || sign2 == 'Capricorn')
    {
        sign2 = 'earth';
    }
    else if(sign2 == 'Gemini' || sign2 == 'Libra' || sign2 == 'Aquarius')
    {
        sign2 = 'air';
    }
    else if(sign2 == 'Cancer' || sign2 == 'Scorpio' || sign2 == 'Pisces')
    {
        sign2 = 'water';
    }
    
    if(sign == )
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            case 8:cout<<"int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string name1, name2, name3;
    int time1, time2, time3;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Race Ranking Program" << endl;
    cout << "Input 3 Runners\nTheir names, then their times" << endl;
    cin >> name1 >> time1 >> name2 >> time2 >> name3 >> time3;
    
    if(time1 > time2 && time1 > time3)
    {
        if(time2 > time3)
        {
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name1 << "\t" << setw(3) << time1;
        }
        else
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name1 << "\t" << setw(3) << time1;
    }
    
    else if(time3 > time1 && time3 > time2)
    {
        if(time1 < time2)
        {
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name3 << "\t" << setw(3) << time3;    
        }
        else
        {
        cout << name2 << "\t" << setw(3) << time2 << endl;
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name3 << "\t" << setw(3) << time3;   
        }
    }
    
    else if(time2 > time1 && time2 > time3)
    {
        if(time1 < time3)
        {
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name2 << "\t" << setw(3) << time2;
        }
        else
        {
        cout << name3 << "\t" << setw(3) << time3 << endl;
        cout << name1 << "\t" << setw(3) << time1 << endl;
        cout << name2 << "\t" << setw(3) << time2;
        }
    }
    //Exit stage right or left!
    return 0;
}"<<endl;break;
            default:cout<<"Exiting the Menu"<<endl;
        }
    }while(choose>=0 && choose<=8);

    return 0;
}